package com.uty.myapplication

object pass {
    var id: String = ""

    fun setId(id: String):String{
        this.id = id
        return id
    }
}