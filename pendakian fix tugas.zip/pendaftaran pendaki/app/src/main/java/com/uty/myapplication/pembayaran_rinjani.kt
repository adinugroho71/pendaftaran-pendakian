package com.uty.myapplication

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class pembayaran_rinjani : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_pembayaran_rinjani)
    }
}
