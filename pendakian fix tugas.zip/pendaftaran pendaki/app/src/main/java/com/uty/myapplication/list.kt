package com.uty.myapplication

class list {
    var id: Int = 0
    var nama: String = ""
    var alamat: String = ""
    var naik: String = ""
    var turun: String = ""
    var telp: String = ""
    var gunung: String = ""
    var rombongan: String = ""


    constructor(
        id: Int,
        nama: String,
        alamat: String,
        naik: String,
        turun: String,
        telp: String,
        gunung: String,
        rombongan: String
    ) {
        this.id = id
        this.nama = nama
        this.alamat = alamat
        this.naik = naik
        this.turun = turun
        this.telp = telp
        this.gunung = gunung
        this.rombongan = rombongan
    }



}